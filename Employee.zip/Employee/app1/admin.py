from django.contrib import admin
from app1.models import Employee
admin.site.register(Employee)
# Register your models here.
